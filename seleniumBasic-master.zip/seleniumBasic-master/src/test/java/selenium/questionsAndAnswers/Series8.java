package selenium.questionsAndAnswers;

public class Series8 {
	/**
	 How many test script do you write
	 What are your role and responsibilities
	 How many team members you have in your team
	 Is it possible to automate in sprint
	 How do you execute test scripts
	 what is source code management you use
	 do you do parallel testing
	 what is you challenge in automation
	 */
	
	/**
1.	Involved in evaluating Selenium for Web UI Automation
2.	Involved in designing and implementing a Selenium web Driver automation framework built using Selenium web Driver + TestNG as Execution Engine.
3.	Involved in designing automation scripts.
4.	Performed automated Regression testing, in coordination with manual testing team.
5.	Updated and maintained various test artifacts in the Test Automation Framework depending on the changes required.


<suite name="basicAnnotaions" parallel="classes" thread-count="3">

	 */
}
