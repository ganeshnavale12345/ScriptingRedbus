package selenium.questionsAndAnswers;

public class Series1 {
	/**
	What is Selenium.
	Does Selenium support automation of pages Made in PHP and HTML.
	Does selenium support automation of application made in only java.
	Does selenium support desktop application automation
	Does selenium has execution engine.
	Does selenium has excel reading methods
	What is components of Selenium
	What are the limitations of Selenium?
	What are the different types of locators in Selenium?
	What is selenium Grid
	
	 */
	
	/**
	 What are the limitations of Selenium?
	 
	 Selenium supports testing of only web based applications
     Mobile applications cannot be tested using Selenium
     Captcha and Bar code readers cannot be tested using Selenium
     Reports can only be generated using third party tools like TestNG or Junit.
     As Selenium is a free tool, thus there is no ready vendor support though the user can find numerous helping communities.
     User is expected to possess prior programming language knowledge.

	 What are the different types of locators in Selenium?
	 
	 ID
     ClassName
     Name
     TagName
     LinkText
     PartialLinkText
     Xpath
     CSS Selector
	 */

}
